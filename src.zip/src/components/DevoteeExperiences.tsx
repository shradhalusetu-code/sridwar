/*
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, FormEvent } from "react";
import { 
  ChevronLeft, 
  ChevronRight, 
  Star, 
  ShieldCheck, 
  Heart, 
  PlusCircle, 
  MapPin, 
  CheckCircle, 
  X,
  Users,
  Feather
} from "lucide-react";
import SriDwarLogo from "./SriDwarLogo";
import { syncToGoogleForm } from "../utils/googleFormSync";
import { recordFormSubmission, recordActivity } from "../lib/activities";
import UPIPaymentModal from "./UPIPaymentModal";
import { validateName, validateTextMinLength } from "../utils/formValidation";

interface Testimonial {
  id: string;
  name: string;
  location: string;
  serviceName: string;
  story: string;
  rating: number;
  badge: string;
  date: string;
  avatarSeed: string; // for consistent styling
  avatarUrl?: string;
}

// Real devotee stories, drawn from the same devotee names, cities and pujas
// shared across the Seva Hub "Sacred Moments" panel and the Prayer Wall
// (see src/data/devoteeReviews.ts). Each entry uses the devotee's first
// name only, their city/state/country, the puja they sponsored, and the
// temple it was offered at — no dates or photos are attached.
const DEFAULT_TESTIMONIALS: Testimonial[] = [
  {
    id: "t1",
    name: "Aarav",
    location: "Delhi, Delhi, India",
    serviceName: "Kashi Vishwanath Rudrabhishek",
    story: "My father battled ill health for months. We booked Rudrabhishek at Kashi Vishwanath for him. Watching the sacred chants read with his name and gotra brought tears of hope. Days later, his smile returned. Sri Dwar turned our prayer into a lived miracle.",
    rating: 5,
    badge: "Story",
    date: "",
    avatarSeed: "aarav",
  },
  {
    id: "t2",
    name: "Aditya",
    location: "Mumbai, Maharashtra, India",
    serviceName: "Ayodhya Ram Mandir Annadaan",
    story: "Sponsoring Annadaan at Ayodhya felt like feeding Lord Ram's own family. The WhatsApp updates made distance disappear — I felt present in every plate served. My heart has never felt fuller.",
    rating: 4.5,
    badge: "Story",
    date: "",
    avatarSeed: "aditya",
  },
  {
    id: "t3",
    name: "Arjun",
    location: "Bengaluru, Karnataka, India",
    serviceName: "Kashi Vishwanath Live Rudrabhishek",
    story: "Watching the live Rudrabhishek from Kashi Vishwanath filled our home with an energy I can't describe. My children sat in silence, eyes wide, hearts open. That evening changed how we pray together forever.",
    rating: 5,
    badge: "Story",
    date: "",
    avatarSeed: "arjun",
  },
  {
    id: "t4",
    name: "Krishna",
    location: "Hyderabad, Telangana, India",
    serviceName: "Kashi Vishwanath Mahamrityunjaya Jaap",
    story: "When my mother fell seriously ill, we booked the Mahamrityunjaya Jaap at Kashi Vishwanath. Every mantra felt like a shield around her. Her recovery since has felt nothing short of divine grace.",
    rating: 4.5,
    badge: "Story",
    date: "",
    avatarSeed: "krishna",
  },
  {
    id: "t5",
    name: "Shivansh",
    location: "Chennai, Tamil Nadu, India",
    serviceName: "Puri Jagannath Chhappan Bhog",
    story: "For our wedding anniversary, we sponsored Chhappan Bhog at Puri Jagannath. Seeing fifty-six dishes offered in Lord Jagannath's name, from so far away, made our small home feel wrapped in his blessing.",
    rating: 5,
    badge: "Story",
    date: "",
    avatarSeed: "shivansh",
  },
  {
    id: "t6",
    name: "Shiv",
    location: "Kolkata, West Bengal, India",
    serviceName: "Badrinath Darshan Seva",
    story: "The live darshan from Badrinath felt like standing inside the sanctum myself. My grandmother, who can no longer travel, wept watching from her bed. Sri Dwar gave her the pilgrimage she thought was lost.",
    rating: 4,
    badge: "Story",
    date: "",
    avatarSeed: "shiv",
  },
  {
    id: "t7",
    name: "Rohan",
    location: "Pune, Maharashtra, India",
    serviceName: "Kashi Vishwanath Rudrabhishek",
    story: "Living far from home, I never thought I could sponsor a Rudrabhishek at Kashi Vishwanath myself. The entire process felt personal and sacred, like the priests knew exactly whose prayer they were carrying.",
    rating: 5,
    badge: "Story",
    date: "",
    avatarSeed: "rohan",
  },
  {
    id: "t8",
    name: "Karthik",
    location: "Jaipur, Rajasthan, India",
    serviceName: "Ayodhya Gurukul Book Seva",
    story: "I sponsored Sanskrit books for children at a Gurukul near Ayodhya. Seeing them hold the very books I gave, faces lit with joy, taught me giving itself is the truest form of prayer.",
    rating: 4.5,
    badge: "Story",
    date: "",
    avatarSeed: "karthik",
  },
  {
    id: "t9",
    name: "Sandeep",
    location: "Visakhapatnam, Andhra Pradesh, India",
    serviceName: "Ayodhya Ram Mandir Seva",
    story: "We sponsored a temple seva at the Ayodhya Ram Mandir exactly as promised, down to the smallest ritual detail. Knowing our Sankalp reached Lord Ram's own sanctum brought a peace words can't hold.",
    rating: 4,
    badge: "Story",
    date: "",
    avatarSeed: "sandeep",
  },
  {
    id: "t10",
    name: "Pranav",
    location: "Bhubaneswar, Odisha, India",
    serviceName: "Lingaraj Temple Annadaan",
    story: "Instead of a birthday party for my son, we sponsored Annadaan at Lingaraj Temple. Watching devotees eat in his name taught him more about gratitude than any gift ever could. Best decision we made.",
    rating: 5,
    badge: "Story",
    date: "",
    avatarSeed: "pranav",
  },
  {
    id: "t11",
    name: "Sanjiv",
    location: "Cuttack, Odisha, India",
    serviceName: "Puri Jagannath Chhappan Bhog",
    story: "Even through a screen, the devotion of the Puri Jagannath priests during our Chhappan Bhog seva touched something deep in me. It felt less like watching and more like being personally blessed.",
    rating: 4.5,
    badge: "Story",
    date: "",
    avatarSeed: "sanjiv",
  },
  {
    id: "t12",
    name: "Gaurav",
    location: "Amritsar, Punjab, India",
    serviceName: "Kashi Vishwanath Rudrabhishek",
    story: "Sri Dwar let me stay rooted in Sanatan tradition despite my hectic life. Sponsoring a Kashi Vishwanath Rudrabhishek from Amritsar reminded me that devotion never needs distance, only sincerity of heart.",
    rating: 4,
    badge: "Story",
    date: "",
    avatarSeed: "gaurav",
  },
  {
    id: "t13",
    name: "Dev",
    location: "Varanasi, Uttar Pradesh, India",
    serviceName: "Kashi Vishwanath Sankalp Puja",
    story: "Living right here in Varanasi, I still chose Sri Dwar for my Sankalp Puja at Kashi Vishwanath. Hearing my name and family lineage spoken aloud during the ritual was a moment I will carry forever.",
    rating: 5,
    badge: "Story",
    date: "",
    avatarSeed: "dev",
  },
  {
    id: "t14",
    name: "Om",
    location: "Ludhiana, Punjab, India",
    serviceName: "Kashi Vishwanath Shravan Rudrabhishek",
    story: "This Shravan, I sponsored a Rudrabhishek at Kashi Vishwanath for my whole family's wellbeing. The spiritual upliftment I felt afterward stayed with me for weeks, calm and steady in a way I hadn't known.",
    rating: 4.5,
    badge: "Story",
    date: "",
    avatarSeed: "om",
  },
  {
    id: "t15",
    name: "Manjunath",
    location: "Mysore, Karnataka, India",
    serviceName: "Vrindavan Gau Seva",
    story: "Sponsoring Gau Seva in Vrindavan gave me a quiet joy I didn't expect. Knowing the cows were fed fresh fodder in my family's name felt like offering love straight to Krishna himself.",
    rating: 4,
    badge: "Story",
    date: "",
    avatarSeed: "manjunath",
  },
  {
    id: "t16",
    name: "Ramesh",
    location: "Kochi, Kerala, India",
    serviceName: "Guruvayur Temple Seva",
    story: "From booking to blessing, sponsoring a seva at Guruvayur Temple through Sri Dwar was seamless and sincere. Grateful that sacred rituals are now just a few taps away, wherever life takes us.",
    rating: 5,
    badge: "Story",
    date: "",
    avatarSeed: "ramesh",
  },
  {
    id: "t17",
    name: "Aditi",
    location: "London, England, United Kingdom",
    serviceName: "Badrinath Live Darshan",
    story: "Thousands of miles from India, watching live darshan from Badrinath made me feel instantly home. The photos and videos of the ritual brought tears — a connection to my roots I feared I'd lost.",
    rating: 4.5,
    badge: "Story",
    date: "",
    avatarSeed: "aditi",
  },
  {
    id: "t18",
    name: "Ananya",
    location: "Paris, Île-de-France, France",
    serviceName: "Somnath Vedic Puja",
    story: "Sponsoring a Vedic puja at Somnath Temple from Paris reminded me that faith travels farther than any flight. Every mantra chanted in my name felt like Lord Shiva was listening from across the world.",
    rating: 5,
    badge: "Story",
    date: "",
    avatarSeed: "ananya",
  },
  {
    id: "t19",
    name: "Priya",
    location: "Los Angeles, California, USA",
    serviceName: "Vrindavan Gau Seva",
    story: "On Gopashtami, I sponsored Gau Seva in Vrindavan from Los Angeles. The peace that followed stayed with our whole family for days — proof that sacred intent needs no passport to reach the divine.",
    rating: 4,
    badge: "Story",
    date: "",
    avatarSeed: "priya",
  },
  {
    id: "t20",
    name: "Neha",
    location: "Chicago, Illinois, USA",
    serviceName: "Kashi Vishwanath Vedic Ceremony",
    story: "The Vedic chanting during our Kashi Vishwanath ceremony felt absolutely divine, even streamed to Chicago. My children, born abroad, finally felt a living thread to their grandparents' faith.",
    rating: 4.5,
    badge: "Story",
    date: "",
    avatarSeed: "neha",
  },
  {
    id: "t21",
    name: "Nandini",
    location: "Phoenix, Arizona, USA",
    serviceName: "Tirupati Balaji Griha Pravesh Mahapuja",
    story: "For our new home, we sponsored a Mahapuja at Tirupati Balaji Temple. Watching every ritual performed with such care from Phoenix, we felt Lord Venkateswara's blessing settle over our doorstep before we'd even moved in.",
    rating: 5,
    badge: "Story",
    date: "",
    avatarSeed: "nandini",
  },
  {
    id: "t22",
    name: "Shruti",
    location: "Sydney, New South Wales, Australia",
    serviceName: "Puri Jagannath Family Sankalpa",
    story: "We now book every family occasion puja through Sri Dwar. Our latest Sankalpa at Puri Jagannath, offered all the way from Sydney, felt as intimate as standing at the temple gates ourselves.",
    rating: 4.5,
    badge: "Story",
    date: "",
    avatarSeed: "shruti",
  },
  {
    id: "t23",
    name: "Gauri",
    location: "Brisbane, Queensland, Australia",
    serviceName: "Puri Jagannath Chhappan Bhog",
    story: "Sponsoring Chhappan Bhog seva at Puri Jagannath from Brisbane, and receiving such thorough documentation of every offering, made an ocean of distance feel like nothing at all. Truly beautiful devotion.",
    rating: 5,
    badge: "Story",
    date: "",
    avatarSeed: "gauri",
  }
];

/** Fisher–Yates shuffle — returns a new array in random order without mutating the input. */
function shuffleArray<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export default function DevoteeExperiences() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Form state
  const [newName, setNewName] = useState("");
  const [newLocation, setNewLocation] = useState("");
  const [newService, setNewService] = useState("");
  const [newStory, setNewStory] = useState("");
  const [newRating, setNewRating] = useState(5);
  const [isSubmitSuccess, setIsSubmitSuccess] = useState(false);
  const [showUPI, setShowUPI] = useState(false);
  const [testimonyRefId, setTestimonyRefId] = useState("");

  // Load from localStorage or defaults
  useEffect(() => {
    const saved = localStorage.getItem("sridwar_devotee_reviews");
    if (saved) {
      try {
        setTestimonials(shuffleArray(JSON.parse(saved)));
      } catch (e) {
        setTestimonials(shuffleArray(DEFAULT_TESTIMONIALS));
      }
    } else {
      setTestimonials(shuffleArray(DEFAULT_TESTIMONIALS));
    }
  }, []);

  const saveTestimonials = (items: Testimonial[]) => {
    setTestimonials(items);
    localStorage.setItem("sridwar_devotee_reviews", JSON.stringify(items));
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  // Modal closed without paying — sends the ONE Final row for this
  // testimony, sharing the same Ref ID, with the contribution correctly
  // recorded as "Skipped".
  const handleSkipContribution = async () => {
    setShowUPI(false);
    try {
      await syncToGoogleForm("prasad_testimony", {
        name: newName,
        email: newLocation,
        phone: newService,
        details: `${newStory} [Contribution: Skipped] [Ref: ${testimonyRefId}]`,
        type: String(newRating)
      });
    } catch (err) {
      console.error("Testimony sync error:", err);
    }
    recordFormSubmission({
      formType: "testimonial",
      name: newName,
      refId: testimonyRefId,
      payload: { location: newLocation, service: newService, story: newStory, rating: newRating, contribution: "skipped" },
    });
  };

  // Payment confirmed — sends the ONE Final row for this testimony, sharing
  // the same Ref ID, with the contribution correctly recorded as the real
  // amount + method paid.
  const handleContributionConfirmed = async (details: { amount: number; method: "UPI" | "WhatsApp Pay" }) => {
    setShowUPI(false);
    try {
      await syncToGoogleForm("prasad_testimony", {
        name: newName,
        email: newLocation,
        phone: newService,
        details: `${newStory} [Contribution: ₹${details.amount} via ${details.method}] [Ref: ${testimonyRefId}]`,
        type: String(newRating)
      });
    } catch (err) {
      console.error("Testimony sync error:", err);
    }
    recordFormSubmission({
      formType: "testimonial",
      name: newName,
      refId: testimonyRefId,
      payload: { location: newLocation, service: newService, story: newStory, rating: newRating, contribution: `₹${details.amount} via ${details.method}` },
    });
    recordActivity({
      activityType: "contribution",
      itemName: `Testimonial Thank-You Contribution — ${newService}`,
      amount: details.amount,
      refId: testimonyRefId,
      paymentMethod: details.method,
      paymentStatus: "pending_verification",
    });
  };

  const handleSubmitReview = async (e: FormEvent) => {
    e.preventDefault();

    // ── Global validation ────────────────────────────────────────────────────
    const nameErr     = validateName(newName);
    const locationErr = validateTextMinLength(newLocation, "Location", 2);
    const serviceErr  = newService.trim() ? null : "Please select or name the service/puja received.";
    const storyErr    = validateTextMinLength(newStory, "Your testimony", 30);
    if (nameErr)     { alert(nameErr);     return; }
    if (locationErr) { alert(locationErr); return; }
    if (serviceErr)  { alert(serviceErr);  return; }
    if (storyErr)    { alert(storyErr);    return; }
    // ────────────────────────────────────────────────────────────────────────

    const newRef = "SDT-" + Math.floor(100000 + Math.random() * 900000);
    setTestimonyRefId(newRef);

    // ✅ Sync to Google Forms first — ONE row, with the optional thank-you
    // contribution correctly recorded as "Pending — Awaiting Decision" (not
    // silently omitted). If the devotee closes the UPI modal without
    // contributing, OR confirms a contribution, handleContributionConfirmed
    // / handleSkipContribution below send exactly ONE more row — same Ref
    // ID — with the real outcome.
    try {
      await syncToGoogleForm("prasad_testimony", {
        name: newName,
        email: newLocation,   // location goes into email field (entry.1921900509)
        phone: newService,    // service goes into phone field (entry.151571055)
        details: `${newStory} [Contribution: Pending — Awaiting Decision] [Ref: ${newRef}]`,
        type: String(newRating)
      });
    } catch (err) {
      console.error("Testimony sync error:", err);
    }

    // ✅ Show optional UPI contribution after testimony submission
    setShowUPI(true);

    const newReview: Testimonial = {
      id: "review_" + Date.now(),
      name: newName,
      location: newLocation,
      serviceName: newService,
      story: newStory,
      rating: newRating,
      badge: "Submitted by a Devotee",
      date: "Received Today",
      avatarSeed: newName.toLowerCase().replace(/\s+/g, "")
    };

    const updated = [newReview, ...testimonials];
    saveTestimonials(updated);
    setIsSubmitSuccess(true);
    setCurrentIndex(0); // Show the new experience first

    // Reset form
    setTimeout(() => {
      setNewName("");
      setNewLocation("");
      setNewService("");
      setNewStory("");
      setNewRating(5);
      setIsSubmitSuccess(false);
      setIsModalOpen(false);
    }, 2000);
  };

  if (testimonials.length === 0) return null;

  const currentDevotee = testimonials[currentIndex];

  return (
    <section id="devotee-experiences-section" className="relative py-16 bg-gradient-to-b from-[#021816] to-[#042825] border-t border-white/10 overflow-hidden">
      {/* Sacred background patterns */}
      <div className="absolute inset-0 pointer-events-none opacity-5">
        <div className="absolute top-1/2 left-1/4 w-80 h-80 rounded-full bg-[#FFB347] blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-[#5EEAD4] blur-[150px]" />
      </div>

      <div className="max-w-6xl mx-auto px-4 relative z-10">
        
        {/* Header styling */}
        <div className="text-center space-y-2 mb-6">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10">
            <Users className="w-3.5 h-3.5 text-[#5EEAD4]" />
            <span className="text-[10px] font-mono tracking-widest text-[#FFB347] uppercase font-bold">
              Devotee Experiences
            </span>
          </div>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-white tracking-tight">
            Divine Miracles & Success Stories
          </h2>
        </div>

        {/* Carousel Container */}
        <div className="relative max-w-4xl mx-auto">
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center bg-[#062421]/90 rounded-3xl border border-white/10 p-6 md:p-10 shadow-2xl relative overflow-hidden backdrop-blur-md">
            
            {/* Spiritual symbol decoration */}
            <div className="absolute top-4 right-6 text-white/5 font-serif text-8xl pointer-events-none select-none">
              ॐ
            </div>

            {/* Left Column: Avatar & Service Details */}
            <div className="md:col-span-4 flex flex-col items-center text-center border-b md:border-b-0 md:border-r border-white/10 pb-6 md:pb-0 md:pr-8">
              {/* Profile Avatar icon placeholder representation */}
              <div className="w-20 h-20 rounded-full flex items-center justify-center mb-4 border-2 border-[#FFB347]/30 shadow-lg relative overflow-hidden bg-[#021816]">
                {currentDevotee.avatarUrl ? (
                  <img
                    src={currentDevotee.avatarUrl}
                    alt={currentDevotee.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <span className="text-3xl font-serif font-black uppercase text-[#FFB347]">
                    {currentDevotee.name.charAt(0)}
                  </span>
                )}
                {/* Small heart/star badge details */}
                <div className="absolute -bottom-1 -right-1 bg-teal-500 text-white rounded-full p-1 border border-[#062421] shadow z-10">
                  <CheckCircle className="w-3.5 h-3.5" />
                </div>
              </div>

              <h4 className="font-serif text-xl font-bold text-white tracking-tight">{currentDevotee.name}</h4>
              <div className="flex items-center text-white/50 text-xs mt-1">
                <MapPin className="w-3.5 h-3.5 text-[#5EEAD4] mr-1" />
                {currentDevotee.location}
              </div>

              {/* Service Tag */}
              <div className="mt-4 px-3 py-1.5 rounded-xl bg-teal-950/80 border border-[#5EEAD4]/20 text-[11px] font-sans font-bold text-[#5EEAD4] tracking-wide uppercase">
                {currentDevotee.serviceName}
              </div>
            </div>

            {/* Right Column: Quote & Story */}
            <div className="md:col-span-8 flex flex-col justify-between py-2 pl-0 md:pl-4 min-h-[220px]">
              <div>
                {/* Trust Stars — supports half-star ratings like 4.5 */}
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(5)].map((_, i) => {
                    const fillPercent = Math.max(0, Math.min(1, currentDevotee.rating - i)) * 100;
                    return (
                      <span key={i} className="relative inline-block w-4 h-4">
                        <Star className="absolute inset-0 w-4 h-4 text-white/20" />
                        <span className="absolute inset-0 overflow-hidden" style={{ width: `${fillPercent}%` }}>
                          <Star className="w-4 h-4 text-[#FFB347] fill-[#FFB347]" />
                        </span>
                      </span>
                    );
                  })}
                  <span className="text-xs text-white/50 font-mono pl-1">({currentDevotee.rating})</span>
                </div>

                {/* Quote details */}
                <div className="relative">
                  <span className="absolute -top-6 -left-3 text-white/10 font-serif text-7xl select-none">“</span>
                  <p className="text-sm md:text-base text-white/80 italic leading-relaxed relative z-10 pl-2">
                    {currentDevotee.story}
                  </p>
                </div>
              </div>

              {/* Bottom Stamp Badge */}
              <div className="mt-6 pt-4 border-t border-white/5 flex flex-wrap items-center gap-4">
                <div className="flex items-center space-x-2 bg-emerald-950/40 border border-emerald-500/20 rounded-lg px-2.5 py-1 text-emerald-400 text-xs font-bold font-sans">
                  <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{currentDevotee.badge}</span>
                </div>
              </div>

            </div>

          </div>

          {/* Nav Controls */}
          <div className="flex items-center gap-3 mt-6">
            <button
              id="devotee-carousel-prev"
              onClick={handlePrev}
              aria-label="Previous devotee story"
              className="flex-shrink-0 p-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-white transition-all cursor-pointer shadow hover:text-[#5EEAD4]"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {/* Pagination indicators dots — scrolls horizontally instead of pushing the arrows off-screen when there are many stories */}
            <div className="flex-1 min-w-0 overflow-x-auto no-scrollbar">
              <div className="flex items-center justify-center space-x-2 w-max mx-auto px-1">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`h-2 rounded-full transition-all duration-300 flex-shrink-0 ${index === currentIndex ? "w-6 bg-[#FFB347]" : "w-2 bg-white/20 hover:bg-white/40"}`}
                    title={`Go to story ${index + 1}`}
                  />
                ))}
              </div>
            </div>

            <button
              id="devotee-carousel-next"
              onClick={handleNext}
              aria-label="Next devotee story"
              className="flex-shrink-0 p-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-white transition-all cursor-pointer shadow hover:text-[#5EEAD4]"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

        </div>

        {/* Action Button: Share Testimonial */}
        <div className="mt-8 text-center" id="devotee-experiences-action">
          <button
            onClick={() => setIsModalOpen(true)}
            className="relative inline-flex items-center space-x-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#FF6B00] to-[#FF9900] hover:from-[#FF8C00] hover:to-[#FFB300] text-white font-extrabold text-xs uppercase tracking-widest shadow-xl transition-all hover:scale-105 border border-[#FFD700]/60 cursor-pointer"
            style={{
              boxShadow: "0 0 20px rgba(255, 107, 0, 0.5), 0 0 40px rgba(255, 107, 0, 0.25)",
              animation: "shareStoryPulse 2s ease-in-out infinite",
            }}
          >
            {/* Outer glow ring */}
            <span
              className="absolute inset-0 rounded-full"
              style={{ animation: "shareStoryRing 2s ease-in-out infinite" }}
              aria-hidden="true"
            />
            <Feather className="w-4 h-4 text-[#FFD700] shrink-0" style={{ animation: "shareStoryFlicker 1.5s ease-in-out infinite alternate" }} />
            <span>Share Your Devotion Story</span>
          </button>
        </div>

        {/* Keyframes for the Share Story button pulse — matches the Setu Yatra Challenge button treatment */}
        <style>{`
          @keyframes shareStoryPulse {
            0%, 100% { box-shadow: 0 0 20px rgba(255,107,0,0.5), 0 0 40px rgba(255,107,0,0.25); transform: scale(1); }
            50%       { box-shadow: 0 0 32px rgba(255,153,0,0.8), 0 0 64px rgba(255,153,0,0.4); transform: scale(1.04); }
          }
          @keyframes shareStoryRing {
            0%, 100% { box-shadow: 0 0 0 0 rgba(255,215,0,0.0); }
            50%       { box-shadow: 0 0 0 6px rgba(255,215,0,0.18); }
          }
          @keyframes shareStoryFlicker {
            0%   { opacity: 1;   transform: rotate(-5deg) scale(1.05); }
            100% { opacity: 0.75; transform: rotate(5deg)  scale(0.95); }
          }
        `}</style>

      </div>

      {/* Share Testimonial Overlay Modal */}
      {isModalOpen && (
          <div
            id="share-story-modal"
            className="fixed inset-0 z-[200] flex flex-col justify-end sm:justify-center sm:items-center sm:p-4 animate-fadeIn"
            style={{ touchAction: "pan-y" }}
            onClick={(e) => { if (e.target === e.currentTarget) setIsModalOpen(false); }}
          >
            <div
              className="fixed inset-0 bg-black/80 backdrop-blur-sm"
              onClick={() => setIsModalOpen(false)}
            />
            
            <div
              className="relative w-full sm:max-w-lg bg-[#042825] border border-white/10 rounded-t-3xl sm:rounded-3xl shadow-2xl z-10 flex flex-col overflow-hidden animate-slideUp"
              style={{ maxHeight: "100%" }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Gold border top accent */}
              <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-[#5EEAD4] via-[#FFB347] to-[#5EEAD4] z-10" />
              
              <button
                onClick={() => setIsModalOpen(false)}
                className="absolute top-4 right-4 text-white/50 hover:text-white transition-colors p-1 z-10"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Scrollable body — THE ONLY scroll container */}
              <div
                className="flex-1 min-h-0 overflow-y-auto p-6 sm:p-8"
                style={{ WebkitOverflowScrolling: "touch", paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 32px)" }}
              >
              <div className="flex justify-center mb-2">
                <SriDwarLogo variant="colored" iconSize="sm" showTagline={false} />
              </div>

              <h3 className="font-serif text-2xl font-bold text-white text-center pb-1">
                Share Prasad & Prayer Testimony
              </h3>
              <p className="text-xs text-white/60 text-center max-w-sm mx-auto mb-6">
                Tell other devotees about the blessings, grace, or sacred resolution you felt. Every story builds faith.
              </p>

              {isSubmitSuccess ? (
                <div className="py-12 text-center space-y-4 animate-fadeIn">
                  <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/40">
                    <CheckCircle className="w-8 h-8" />
                  </div>
                  <h4 className="font-serif text-xl font-bold text-[#5EEAD4]">Sankalpa Review Submitted!</h4>
                  <p className="text-xs text-white/70 max-w-xs mx-auto">
                    Thank you for sharing your spiritual testimony. Your story has been added and synchronized securely to your browser storage.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmitReview} className="space-y-4 text-left">
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-white/70 uppercase tracking-widest mb-1.5">Your Name</label>
                      <input 
                        required
                        type="text" 
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                        placeholder="e.g. Ramesh Patel"
                        className="w-full bg-[#021816]/80 text-white border border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-[#5EEAD4] transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-white/70 uppercase tracking-widest mb-1.5">Devotee Location</label>
                      <input 
                        required
                        type="text" 
                        value={newLocation}
                        onChange={(e) => setNewLocation(e.target.value)}
                        placeholder="e.g. Ahmedabad, Gujarat"
                        className="w-full bg-[#021816]/80 text-white border border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-[#5EEAD4] transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-white/70 uppercase tracking-widest mb-1.5">Spiritual Seva or Puja Availed</label>
                    <input 
                      required
                      type="text" 
                      value={newService}
                      onChange={(e) => setNewService(e.target.value)}
                      placeholder="e.g. Somnath Mahadev Sankalpa Puja"
                      className="w-full bg-[#021816]/80 text-white border border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-[#5EEAD4] transition-colors"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1.5">
                      <label className="block text-[10px] font-bold text-white/70 uppercase tracking-widest">Devotion Rating</label>
                      <span className="text-[10px] font-mono text-[#FFB347] font-bold">{newRating} Star Gratitude</span>
                    </div>
                    <div className="flex space-x-2 bg-[#021816]/50 p-2 rounded-xl border border-white/5 w-fit">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setNewRating(star)}
                          className="hover:scale-110 transition-transform p-0.5"
                        >
                          <Star className={`w-6 h-6 ${star <= newRating ? "text-[#FFB347] fill-[#FFB347]" : "text-white/20"}`} />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-white/70 uppercase tracking-widest mb-1.5">Your Experience / Miraculous Story</label>
                    <textarea 
                      required
                      rows={4}
                      value={newStory}
                      onChange={(e) => setNewStory(e.target.value)}
                      placeholder="Describe the peaceful transition, positive energetic shift, or receipt of prasad you experienced after completing the rituals..."
                      className="w-full bg-[#021816]/80 text-white border border-white/10 rounded-xl p-3 text-xs focus:outline-none focus:border-[#5EEAD4] transition-colors resize-none leading-relaxed"
                    />
                  </div>

                  {/* Submission agreement check */}
                  <div className="flex items-start space-x-2 text-[10px] text-white/60">
                    <input type="checkbox" required defaultChecked className="mt-0.5" />
                    <span>I agree Sri Dwar may review this testimony and feature it on this page for other devotees to read.</span>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#5EEAD4] to-[#2dd4bf] text-[#021816] font-bold text-xs tracking-widest uppercase shadow-lg hover:opacity-95 transition-opacity mt-4 cursor-pointer"
                  >
                    Transmit Review Securely
                  </button>

                </form>
              )}
              </div>
            </div>
          </div>
      )}
      {/* Optional UPI contribution after testimony */}
      <UPIPaymentModal
        isOpen={showUPI}
        onClose={handleSkipContribution}
        onPaymentConfirmed={handleContributionConfirmed}
        amount={null}
        bookingName="Optional Contribution — Temple Support"
        devoteeName={newName}
        refId={testimonyRefId}
        allowCustomAmount={true}
        minAmount={5}
        maxAmount={1000}
      />
    </section>
  );
}
