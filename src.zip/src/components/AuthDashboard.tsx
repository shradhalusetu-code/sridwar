/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect, FormEvent } from "react";
import { User, ShieldCheck, Mail, Phone, Calendar, RefreshCw, LogOut, Award, Layers, Plus, Trash2, Save, Lock, AlertCircle, UserPlus, LogIn, Landmark, Utensils, Armchair, Hammer, FileCheck } from "lucide-react";
import { Language, TRANSLATIONS } from "../data/translations";
import { TEMPLES_LIST } from "../data/temples";
import { supabase } from "../lib/supabaseClient";
import SriDwarLogo from "./SriDwarLogo";
import OptimizedImage from "./OptimizedImage";
import dharmicIdBg from "../assets/images/Dharmic_ID.jpg";
// @ts-ignore
import dharmicIdBgWebp from "../assets/images/Dharmic_ID.webp";
import sridwarQR from "../assets/images/SridwarQR.jpg";
// @ts-ignore
import sridwarQRWebp from "../assets/images/SridwarQR.webp";
import UPIPaymentModal from "./UPIPaymentModal";
import { syncToGoogleForm } from "../utils/googleFormSync";
import { gaRegistrationSubmit, gaLogin, gaDonationInitiate } from "../utils/analytics";
import {
  recordActivity, fetchProfileExtra, saveProfileExtra,
  fetchFamilyMembers, syncFamilyMembers,
  fetchActivities, fetchFormSubmissions,
  ActivityRecord, FormSubmissionRecord,
} from "../lib/activities";

interface FamilyMember {
  name: string;
  relation: string;
}

interface AuthDashboardProps {
  currentLanguage: Language;
  isLoggedIn: boolean;
  onLoginSuccess: (name: string, email: string) => void;
  onLogout: () => void;
  userProfile: { name: string; email: string };
  bookedItems: Array<{ pujaName: string; price: number; refId: string; date: string }>;
}

export default function AuthDashboard({
  currentLanguage,
  isLoggedIn,
  onLoginSuccess,
  onLogout,
  userProfile,
  bookedItems
}: AuthDashboardProps) {
  const [userNameField, setUserNameField] = useState("");
  const [userEmailField, setUserEmailField] = useState("");
  const [userGotra, setUserGotra] = useState("Vatsasa Gotra");
  const [userRashi, setUserRashi] = useState("Dhanu (Sagittarius)");
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Real Supabase email/password authentication
  const [authFormMode, setAuthFormMode] = useState<"signup" | "signin">("signup");
  const [passwordField, setPasswordField] = useState("");
  const [authErrorMessage, setAuthErrorMessage] = useState("");
  // True once we've asked a brand-new devotee to confirm their email —
  // shown instead of the form until they switch back to "Log In".
  const [signupNeedsConfirmation, setSignupNeedsConfirmation] = useState(false);

  // Dharmic ID generation step + temple-redevelopment contribution step
  const [authStep, setAuthStep] = useState<"login" | "contribute">("login");
  const [pendingLogin, setPendingLogin] = useState<{ name: string; email: string } | null>(null);
  const [selectedTempleId, setSelectedTempleId] = useState("");
  const [customMandapName, setCustomMandapName] = useState("");
  const [customMandapAddress, setCustomMandapAddress] = useState("");
  const [contributionAmount, setContributionAmount] = useState<number>(0);
  const [isContributionPaymentOpen, setIsContributionPaymentOpen] = useState(false);

  // Puja Sankalpa Portal (step between Contribute click and payment)
  const [showSankalpaForm, setShowSankalpaForm] = useState(false);
  const [sankalpaPhone, setSankalpaPhone] = useState("");
  const [sankalpaGotra, setSankalpaGotra] = useState("");
  const [sankalpaIntent, setSankalpaIntent] = useState("");
  const [contributionRefId, setContributionRefId] = useState("");

  // My Sacred Profile states
  // No placeholder/generic family members are pre-populated here. The
  // Dharmic ID should only ever show family members the devotee has
  // actually entered themselves via "Add family member" below.
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [newMemberName, setNewMemberName] = useState("");
  const [newMemberRelation, setNewMemberRelation] = useState("Spouse");
  const [saveProfileSuccess, setSaveProfileSuccess] = useState(false);
  const [userPhone, setUserPhone] = useState("");

  // Full synced activity ledger (all pujas/sevas/products/contributions/
  // registrations, with real payment status) + non-monetary form
  // submissions (Contact Us, testimonials, Darshan Certificate requests,
  // registrations) for the logged-in devotee — read directly from Supabase
  // so "My Sacred Profile" reflects the devotee's complete account
  // activity on any device, not just this browser's session.
  const [activityRecords, setActivityRecords] = useState<ActivityRecord[]>([]);
  const [formSubmissions, setFormSubmissions] = useState<FormSubmissionRecord[]>([]);

  // Post-login "Contribute / Donate" panel — lets an already-logged-in
  // devotee start a new temple contribution from their Profile page,
  // reusing the same temple/amount selection + Sankalpa + UPI payment flow
  // used during first-time Dharmic ID generation.
  const [showPostLoginContribute, setShowPostLoginContribute] = useState(false);
  const [postLoginContributionSuccess, setPostLoginContributionSuccess] = useState(false);

  // Sync profile details on mount or auth state change.
  // Supabase is the source of truth (so the Dharmic ID looks the same on
  // any device); localStorage is read first only as an instant-paint cache
  // while the DB fetch is in flight, then overwritten once real data lands.
  useEffect(() => {
    if (isLoggedIn) {
      const savedProfileStr = localStorage.getItem("sridwar_sacred_profile");
      if (savedProfileStr) {
        try {
          const profile = JSON.parse(savedProfileStr);
          if (profile.gotra) setUserGotra(profile.gotra);
          if (profile.rashi) setUserRashi(profile.rashi);
          if (profile.phone) setUserPhone(profile.phone);
          if (profile.family) setFamilyMembers(profile.family);
        } catch (e) {
          console.error("Failed to parse saved profile", e);
        }
      }

      // Now reconcile against the real Supabase record.
      Promise.all([
        fetchProfileExtra(),
        fetchFamilyMembers(),
        fetchActivities(),
        fetchFormSubmissions(),
      ]).then(([extra, family, activities, submissions]) => {
        if (extra) {
          if (extra.gotra) setUserGotra(extra.gotra);
          if (extra.rashi) setUserRashi(extra.rashi);
          if (extra.phone) setUserPhone(extra.phone);
        }
        // Only overwrite the family list if the DB actually has rows —
        // an empty DB result on a first-time fetch (e.g. right after
        // signup, before "family_members" table has synced) shouldn't
        // wipe out what's already showing from the localStorage cache.
        if (family.length > 0) {
          setFamilyMembers(family.map((f) => ({ name: f.name, relation: f.relation })));
        }
        setActivityRecords(activities);
        setFormSubmissions(submissions);
      });
    } else {
      // Reset the Dharmic ID generation flow back to the start after logout
      setAuthStep("login");
      setPendingLogin(null);
      setSelectedTempleId("");
      setCustomMandapName("");
      setCustomMandapAddress("");
      setContributionAmount(0);
      setActivityRecords([]);
      setFormSubmissions([]);
      setShowPostLoginContribute(false);
      setPostLoginContributionSuccess(false);
    }
  }, [isLoggedIn]);

  const handleSaveProfile = (e: FormEvent) => {
    e.preventDefault();
    const profile = {
      name: userProfile.name,
      email: userProfile.email,
      gotra: userGotra,
      rashi: userRashi,
      phone: userPhone,
      family: familyMembers
    };
    localStorage.setItem("sridwar_sacred_profile", JSON.stringify(profile));

    // Source of truth — so this profile is visible on any device, not just
    // this browser.
    saveProfileExtra({ gotra: userGotra, rashi: userRashi, phone: userPhone });
    syncFamilyMembers(familyMembers);

    // Also sync to Google Forms/Sheets, same as every other form on the
    // site, so My Sacred Profile updates land in the devotee records sheet
    // too — not just in Supabase.
    syncToGoogleForm("devotee_support", {
      name: userProfile.name,
      email: userProfile.email,
      phone: userPhone,
      type: "Sacred Profile Update",
      details: `Gotra: ${userGotra} | Rashi: ${userRashi} | Family Members: ${
        familyMembers.length > 0
          ? familyMembers.map((m) => `${m.name} (${m.relation})`).join(", ")
          : "None"
      }`,
      gotra: userGotra,
      rashi: userRashi,
    });

    setSaveProfileSuccess(true);
    setTimeout(() => {
      setSaveProfileSuccess(false);
    }, 4000);
  };

  const handleAddFamilyMember = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) {
      alert("Please specify a Family Member devotee name.");
      return;
    }
    const updated = [...familyMembers, { name: newMemberName.trim(), relation: newMemberRelation }];
    setFamilyMembers(updated);
    setNewMemberName("");

    // Persist immediately on list change for best UX
    const profile = {
      name: userProfile.name,
      email: userProfile.email,
      gotra: userGotra,
      rashi: userRashi,
      phone: userPhone,
      family: updated
    };
    localStorage.setItem("sridwar_sacred_profile", JSON.stringify(profile));
    syncFamilyMembers(updated);
  };

  const handleRemoveFamilyMember = (indexToRemove: number) => {
    const updated = familyMembers.filter((_, idx) => idx !== indexToRemove);
    setFamilyMembers(updated);

    // Persist immediately on list change
    const profile = {
      name: userProfile.name,
      email: userProfile.email,
      gotra: userGotra,
      rashi: userRashi,
      phone: userPhone,
      family: updated
    };
    localStorage.setItem("sridwar_sacred_profile", JSON.stringify(profile));
    syncFamilyMembers(updated);
  };

  const t = TRANSLATIONS[currentLanguage];

  // Display helpers for the synced activity ledger below.
  const ACTIVITY_TYPE_LABELS: Record<string, string> = {
    puja: "Puja Booking",
    seva: "Seva / Sponsorship",
    product: "Bazaar Order",
    contribution: "Temple Contribution",
    temple_registration: "Temple Registration",
    darshan_certificate: "Darshan Certificate",
    other: "Other Offering",
  };
  const FORM_TYPE_LABELS: Record<string, string> = {
    contact_us: "Contact Us Message",
    testimonial: "Devotion Story Shared",
    darshan_certificate: "Darshan Certificate Request",
    devotee_registration: "Devotee Registration",
    expert_registration: "Dharmic Expert Registration",
    temple_committee_registration: "Temple Committee Registration",
  };
  const paymentStatusBadge = (status: string) => {
    if (status === "confirmed") {
      return { label: "Confirmed", cls: "bg-emerald-950/60 text-emerald-300 border-emerald-500/30" };
    }
    if (status === "failed") {
      return { label: "Payment Failed", cls: "bg-red-950/50 text-red-300 border-red-500/30" };
    }
    return { label: "Pending Verification", cls: "bg-[#FFB347]/10 text-[#FFB347] border-[#FFB347]/20" };
  };

  const handleGoogleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setAuthErrorMessage("");

    if (authFormMode === "signup" && !userNameField) {
      setAuthErrorMessage("Please specify a Devotee Name to register your Digital Gotra identity.");
      return;
    }
    if (!userEmailField || !passwordField) {
      setAuthErrorMessage("Please specify an Email and Password.");
      return;
    }
    if (passwordField.length < 6) {
      setAuthErrorMessage("Password must be at least 6 characters.");
      return;
    }

    setIsLoggingIn(true);

    if (authFormMode === "signup") {
      // Create the account in Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email: userEmailField,
        password: passwordField,
        options: { data: { name: userNameField } },
      });

      if (error) {
        setAuthErrorMessage(error.message);
        setIsLoggingIn(false);
        return;
      }

      // If "Confirm email" is enabled in Supabase, `data.session` is null
      // here even though the account was created — there is no logged-in
      // session yet. In that case we must NOT try to write to "profiles"
      // (Row Level Security correctly rejects an unauthenticated insert,
      // which is the 401 / 42501 error) and we must NOT treat the devotee
      // as logged in or move them past the login step.
      if (!data.session) {
        setIsLoggingIn(false);
        setSignupNeedsConfirmation(true);
        return;
      }

      // A session exists (email confirmation is off, or already confirmed),
      // so it's safe to save the devotee's profile details now.
      const { error: profileError } = await supabase.from("profiles").upsert({
        id: data.user!.id,
        name: userNameField,
        email: userEmailField,
        gotra: userGotra,
        rashi: userRashi,
        phone: userPhone || null,
      });
      if (profileError) {
        console.error("Could not save profile:", profileError.message);
      }
    } else {
      // Existing devotee logging in
      const { data, error } = await supabase.auth.signInWithPassword({
        email: userEmailField,
        password: passwordField,
      });

      if (error) {
        setAuthErrorMessage(error.message);
        setIsLoggingIn(false);
        return;
      }

      // Make sure their profile row exists — it may not, if it couldn't be
      // created at signup time because email confirmation was still
      // pending. We now have a real session, so this insert is allowed.
      // We only INSERT (never overwrite): the sign-in form doesn't show
      // the name/gotra/rashi fields, so blindly upserting here would
      // silently blank out or reset an existing devotee's saved details
      // on every ordinary login.
      if (data.user) {
        const { data: existingProfile } = await supabase
          .from("profiles")
          .select("id")
          .eq("id", data.user.id)
          .maybeSingle();

        if (!existingProfile) {
          const { error: profileError } = await supabase.from("profiles").insert({
            id: data.user.id,
            name: data.user.user_metadata?.name || userEmailField,
            email: userEmailField,
            gotra: userGotra,
            rashi: userRashi,
            phone: userPhone || null,
          });
          if (profileError) {
            console.error("Could not save profile:", profileError.message);
          }
        }
      }
    }

    setPendingLogin({ name: userNameField, email: userEmailField });
    setIsLoggingIn(false);
    setAuthStep("contribute");
    gaRegistrationSubmit("devotee_registration");
  };

  // Step 7 — Skip Contribution: go directly to Dharmic Portal
  const handleSkipContribution = () => {
    if (pendingLogin) {
      gaLogin("email");
      onLoginSuccess(pendingLogin.name, pendingLogin.email);
      setPendingLogin(null);
    }
  };

  // Step 2 — Contribute clicked: validate amount then show Puja Sankalpa Portal
  const handleProceedToContributionPayment = () => {
    if (!contributionAmount || contributionAmount <= 0) return;
    gaDonationInitiate(contributionAmount);
    setContributionRefId("SDC-" + Math.floor(100000 + Math.random() * 900000));
    setShowSankalpaForm(true);
  };

  // Step 4 — Sankalpa form submitted: sync to Google Form (Pending row) then open payment
  const handleSankalpaSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!sankalpaPhone.trim()) {
      alert("Please enter your WhatsApp number to proceed.");
      return;
    }

    const templeName = selectedTempleId
      ? TEMPLES_LIST.find((t) => t.id === selectedTempleId)?.name || "Selected Temple"
      : customMandapName || "Custom Mandap";

    // Sync Puja Sankalpa data to Google Forms (seva_booking form) — ONE row,
    // recorded as "Pending" since payment hasn't been confirmed yet. The
    // corrected Final row (with real payment method) is sent from
    // finalizeContribution below, sharing the same Ref ID.
    syncToGoogleForm("seva_booking", {
      name:         pendingLogin?.name || userProfile.name || "",
      email:        pendingLogin?.email || userProfile.email || "",
      phone:        sankalpaPhone.trim(),
      gotra:        sankalpaGotra || userGotra || undefined,
      intent:       sankalpaIntent || undefined,
      type:         `Temple Redevelopment Contribution — ${templeName}`,
      details:      `Contribution: ₹${contributionAmount} | Payment Status: Pending — Awaiting Confirmation | Temple: ${templeName} | Gotra: ${sankalpaGotra || userGotra || "Not provided"} | Intent: ${sankalpaIntent || "General blessings"} | Ref: ${contributionRefId}`,
      fee:          contributionAmount,
      temple:       templeName,
      whatsapp:     sankalpaPhone.trim(),
      city:         customMandapAddress || "Online Devotee",
    });

    setShowSankalpaForm(false);
    setIsContributionPaymentOpen(true);
  };

  // Step 6 — After payment confirmed: send the ONE Final row (same Ref ID),
  // with payment status corrected to "Paid — Confirmed" and the real method
  // (UPI or WhatsApp Pay) + actual confirmed amount — then redirect to the
  // Dharmic Portal.
  const finalizeContribution = (details: { amount: number; method: "UPI" | "WhatsApp Pay" }) => {
    setIsContributionPaymentOpen(false);
    const templeName = selectedTempleId
      ? TEMPLES_LIST.find((t) => t.id === selectedTempleId)?.name || "Selected Temple"
      : customMandapName || "Custom Mandap";
    syncToGoogleForm("seva_booking", {
      name:         pendingLogin?.name || userProfile.name || "",
      email:        pendingLogin?.email || userProfile.email || "",
      phone:        sankalpaPhone.trim(),
      gotra:        sankalpaGotra || userGotra || undefined,
      intent:       sankalpaIntent || undefined,
      type:         `Temple Redevelopment Contribution — ${templeName}`,
      details:      `Contribution: ₹${details.amount} | Payment Status: Paid — Confirmed | Payment Method: ${details.method} | Temple: ${templeName} | Gotra: ${sankalpaGotra || userGotra || "Not provided"} | Intent: ${sankalpaIntent || "General blessings"} | Ref: ${contributionRefId}`,
      fee:          details.amount,
      temple:       templeName,
      whatsapp:     sankalpaPhone.trim(),
      city:         customMandapAddress || "Online Devotee",
    });
    // Record into the Supabase activity ledger so this contribution shows
    // up on the Profile page — this was previously the biggest silent gap
    // (contributions never appeared anywhere once the Google Form fired).
    recordActivity({
      activityType: "contribution",
      itemName: `Temple Redevelopment Contribution — ${templeName}`,
      amount: details.amount,
      refId: contributionRefId,
      paymentMethod: details.method,
      paymentStatus: "pending_verification",
    });
    if (pendingLogin) {
      // First-time Dharmic ID generation flow — proceed into the app.
      gaLogin("email_with_contribution");
      onLoginSuccess(pendingLogin.name, pendingLogin.email);
      setPendingLogin(null);
    } else if (isLoggedIn) {
      // Already-logged-in devotee contributing again from their Profile
      // page — stay put, just refresh the ledger and show a confirmation
      // instead of re-running the login flow.
      gaDonationInitiate(details.amount);
      setShowPostLoginContribute(false);
      setSelectedTempleId("");
      setCustomMandapName("");
      setCustomMandapAddress("");
      setContributionAmount(0);
      setPostLoginContributionSuccess(true);
      setTimeout(() => setPostLoginContributionSuccess(false), 6000);
      Promise.all([fetchActivities(), fetchFormSubmissions()]).then(([activities, submissions]) => {
        setActivityRecords(activities);
        setFormSubmissions(submissions);
      });
    }
  };

  // Note: previously this dashboard showed a hardcoded "simulatedHistory"
  // list of completed pujas to every devotee regardless of whether they had
  // actually booked anything — i.e. fabricated personal account history.
  // That has been removed; the dashboard now only shows a devotee's real
  // bookedItems (from this browser session) and an honest empty state.

  return (
    <section id="auth-dashboard-section" className="py-24 bg-[#021816] text-left text-white" style={{ paddingTop: `calc(env(safe-area-inset-top, 0px) + 80px)` }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Conditional Layout based on Logon Status */}
        {!isLoggedIn ? (
          
          /* LOGIN PANEL FORM OVERLAY */
          <div className="max-w-md mx-auto bg-[#092320] rounded-3xl border border-white/10 p-6 sm:p-8 shadow-xl" id="google-login-panel">
            <div className="text-center space-y-3 mb-6">
              <div className="flex justify-center mb-1">
                <SriDwarLogo variant="colored" iconSize="lg" showTagline={false} className="mx-auto flex justify-center" />
              </div>
              <h3 className="font-serif text-2xl font-bold tracking-tight text-white animate-fadeIn">Access My Dharmic ID</h3>
              <p className="text-xs text-white/70 max-w-sm mx-auto">
                Securely generate your permanent digital Gotras identification for Shradhalu Private Limited’s national devalaya network.
              </p>
            </div>

            {authStep === "login" && signupNeedsConfirmation && (
              <div className="space-y-4 text-center animate-fadeIn">
                <div className="flex items-start space-x-2 bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs rounded-xl px-3 py-3 text-left">
                  <Mail className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <span>
                    We've sent a confirmation link to <strong>{userEmailField}</strong>. Please check your inbox
                    and verify your email, then log in below to continue.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => { setAuthFormMode("signin"); setSignupNeedsConfirmation(false); }}
                  className="w-full bg-[#5EEAD4] hover:bg-[#14B8A6] text-[#021816] font-bold py-3 rounded-xl text-xs transition-colors shadow cursor-pointer"
                >
                  GO TO LOG IN
                </button>
              </div>
            )}

            {authStep === "login" && !signupNeedsConfirmation && (
            <form onSubmit={handleGoogleLogin} className="space-y-4">

              {/* Sign Up / Log In toggle */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  id="auth-mode-signup-tab"
                  onClick={() => { setAuthFormMode("signup"); setAuthErrorMessage(""); setSignupNeedsConfirmation(false); }}
                  className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl border text-xs font-bold uppercase tracking-wide transition-all cursor-pointer ${
                    authFormMode === "signup"
                      ? "bg-[#5EEAD4] border-[#5EEAD4] text-[#021816]"
                      : "bg-[#021816] border-white/10 text-white/60 hover:text-white/80"
                  }`}
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Signup</span>
                </button>
                <button
                  type="button"
                  id="auth-mode-signin-tab"
                  onClick={() => { setAuthFormMode("signin"); setAuthErrorMessage(""); setSignupNeedsConfirmation(false); }}
                  className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl border text-xs font-bold uppercase tracking-wide transition-all cursor-pointer ${
                    authFormMode === "signin"
                      ? "bg-[#5EEAD4] border-[#5EEAD4] text-[#021816]"
                      : "bg-[#021816] border-white/10 text-white/60 hover:text-white/80"
                  }`}
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Login</span>
                </button>
              </div>

              {authErrorMessage && (
                <div className="flex items-start space-x-2 bg-red-950/40 border border-red-500/30 text-red-300 text-xs rounded-xl px-3 py-2.5">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <span>{authErrorMessage}</span>
                </div>
              )}

              {/* Devotee Name — only needed when creating a new account */}
              {authFormMode === "signup" && (
              <div>
                <label className="block text-xs font-bold text-white/80 mb-1">Devotee Full Name *</label>
                <div className="relative">
                  <input
                    id="login-field-name"
                    type="text"
                    required
                    placeholder="e.g. Kunu Rana"
                    value={userNameField}
                    onChange={(e) => setUserNameField(e.target.value)}
                    className="w-full text-xs pl-10 pr-4 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-[#5EEAD4] bg-[#021816] text-white font-semibold placeholder-white/30 text-left"
                  />
                  <User className="absolute left-3.5 top-3 w-4 h-4 text-white/40" />
                </div>
              </div>
              )}

              {/* Devotee Email */}
              <div>
                <label className="block text-xs font-bold text-white/80 mb-1">Email Address *</label>
                <div className="relative">
                  <input
                    id="login-field-email"
                    type="email"
                    required
                    placeholder="e.g. kunu@shradhalu.com"
                    value={userEmailField}
                    onChange={(e) => setUserEmailField(e.target.value)}
                    className="w-full text-xs pl-10 pr-4 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-[#5EEAD4] bg-[#021816] text-white font-semibold placeholder-white/30 text-left"
                  />
                  <Mail className="absolute left-3.5 top-3 w-4 h-4 text-white/40" />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-bold text-white/80 mb-1">Password *</label>
                <div className="relative">
                  <input
                    id="login-field-password"
                    type="password"
                    required
                    minLength={6}
                    placeholder="At least 6 characters"
                    value={passwordField}
                    onChange={(e) => setPasswordField(e.target.value)}
                    className="w-full text-xs pl-10 pr-4 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-[#5EEAD4] bg-[#021816] text-white font-semibold placeholder-white/30 text-left"
                  />
                  <Lock className="absolute left-3.5 top-3 w-4 h-4 text-white/40" />
                </div>
              </div>

              {authFormMode === "signup" && (
              <div className="grid grid-cols-2 gap-4 text-left">
                {/* Gotra */}
                <div>
                  <label className="block text-xs font-bold text-white/80 mb-1">Gotra Ancestry</label>
                  <input
                    id="login-field-gotra"
                    type="text"
                    value={userGotra}
                    onChange={(e) => setUserGotra(e.target.value)}
                    placeholder="e.g. Kashyap Gotra"
                    className="w-full text-xs px-3 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-[#5EEAD4] bg-[#021816] text-white font-medium placeholder-white/30 text-left"
                  />
                </div>
                {/* Rashi */}
                <div>
                  <label className="block text-xs font-bold text-white/80 mb-1">Moon Sign (Rashi)</label>
                  <select
                    id="login-field-rashi"
                    value={userRashi}
                    onChange={(e) => setUserRashi(e.target.value)}
                    className="w-full text-xs px-2.5 py-2.5 rounded-xl border border-white/10 bg-[#021816] text-[#5EEAD4] font-medium"
                  >
                    <option value="Mesh (Aries)">Mesh (Aries)</option>
                    <option value="Vrishabh (Taurus)">Vrishabh (Taurus)</option>
                    <option value="Mithun (Gemini)">Mithun (Gemini)</option>
                    <option value="Dhanu (Sagittarius)">Dhanu (Sagittarius)</option>
                    <option value="Meen (Pisces)">Meen (Pisces)</option>
                  </select>
                </div>
              </div>
              )}

              {/* Plain registration submit button — no Google branding or
                  colors, since this form does not use real Google Sign-In/
                  OAuth. Using Google's brand color and a bare "G" here would
                  visually impersonate "Sign in with Google" while actually
                  being an ordinary name/email form, which is both a brand
                  misuse and a deceptive-functionality risk. */}
              <button
                id="devotee-register-trigger"
                type="submit"
                disabled={isLoggingIn}
                className="w-full bg-[#FFB347] hover:bg-[#F27D26] text-[#021816] font-bold py-3 rounded-xl text-xs transition-colors shadow flex items-center justify-center space-x-2 cursor-pointer"
              >
                {isLoggingIn ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-[#021816]" />
                    <span>Connecting to Sri Dwar...</span>
                  </>
                ) : (
                  <>
                    <span className="tracking-wider">
                      {authFormMode === "signup" ? "GENERATE DIGITAL DHARMIC ID" : "LOG IN TO MY DHARMIC ID"}
                    </span>
                  </>
                )}
              </button>

              <div className="flex items-center justify-center space-x-1.5 text-[10px] font-mono text-[#5EEAD4] bg-white/5 py-1.5 rounded-lg border border-white/10">
                <ShieldCheck className="w-3.5 h-3.5 text-[#5EEAD4]" />
                <span>Powered by Sri Dwar Technology</span>
              </div>
            </form>
            )}

            {authStep === "contribute" && (
              <div className="space-y-4 animate-fadeIn text-left">
                <div className="text-center space-y-1">
                  <div className="w-12 h-12 bg-emerald-950/40 rounded-full flex items-center justify-center mx-auto border border-emerald-500/30 mb-2">
                    <Award className="w-6 h-6 text-[#5EEAD4]" />
                  </div>
                  <h4 className="font-serif text-lg font-bold text-[#5EEAD4]">Your Dharmic ID is Ready!</h4>
                  <p className="text-xs text-white/60">
                    Would you like to contribute towards temple redevelopment before entering your dashboard? Your contribution helps preserve our heritage, temples, and Sridwar's mission to build India's trusted devotee community platform and connect devotees worldwide to sacred temples, trusted priests, and dharmic services.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-white/80 mb-1">Choose a temple from our network</label>
                  <select
                    id="contribute-temple-select"
                    value={selectedTempleId}
                    onChange={(e) => {
                      setSelectedTempleId(e.target.value);
                      if (e.target.value) {
                        setCustomMandapName("");
                        setCustomMandapAddress("");
                      }
                    }}
                    className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#021816] text-[#5EEAD4] font-medium focus:outline-none focus:border-[#5EEAD4]"
                  >
                    <option value="">-- Select a temple --</option>
                    {TEMPLES_LIST.map((temple) => (
                      <option key={temple.id} value={temple.id}>{temple.name}</option>
                    ))}
                  </select>
                </div>

                <div className="sanskrit-divider text-[10px]">or</div>

                <div className="space-y-2">
                  <label className="block text-xs font-bold text-white/80 mb-1">Mention your own preferred Puja Mandap</label>
                  <input
                    id="contribute-custom-mandap-name"
                    type="text"
                    placeholder="Mandap / Temple name"
                    value={customMandapName}
                    onChange={(e) => {
                      setCustomMandapName(e.target.value);
                      if (e.target.value) setSelectedTempleId("");
                    }}
                    className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#021816] text-white placeholder-white/30 focus:outline-none focus:border-[#5EEAD4]"
                  />
                  <input
                    id="contribute-custom-mandap-address"
                    type="text"
                    placeholder="Mandap address / city"
                    value={customMandapAddress}
                    onChange={(e) => setCustomMandapAddress(e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#021816] text-white placeholder-white/30 focus:outline-none focus:border-[#5EEAD4]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-white/80 mb-1">Contribution Amount (₹)</label>
                  <div className="grid grid-cols-3 gap-2 mb-2">
                    {[51, 101, 251].map((amt) => (
                      <button
                        key={amt}
                        id={`contribute-amount-tier-${amt}`}
                        type="button"
                        onClick={() => setContributionAmount(amt)}
                        className={`text-xs py-2 rounded-xl border font-bold transition-all ${
                          contributionAmount === amt
                            ? "bg-white/10 border-[#5EEAD4] text-[#5EEAD4] shadow-sm"
                            : "bg-black/20 border-white/10 text-white/70 hover:bg-black/30"
                        }`}
                      >
                        ₹{amt}
                      </button>
                    ))}
                  </div>
                  <input
                    id="contribute-custom-amount"
                    type="number"
                    min={1}
                    placeholder="Or enter a custom amount"
                    value={contributionAmount || ""}
                    onChange={(e) => setContributionAmount(Math.max(0, Number(e.target.value)))}
                    className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#021816] text-white placeholder-white/30 focus:outline-none focus:border-[#5EEAD4]"
                  />
                </div>

                <div className="flex items-start space-x-2 text-[10px] font-mono text-[#5EEAD4] bg-white/5 px-3 py-2 rounded-lg border border-white/10">
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>A specific puja will be performed in your name at your ista devta temple, and the certificate for that puja will be shared with you on WhatsApp & Email within 3 working days of your contribution.</span>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-1">
                  <button
                    id="contribute-skip-btn"
                    type="button"
                    onClick={handleSkipContribution}
                    className="bg-white/5 hover:bg-white/10 text-white font-bold py-3 rounded-xl text-xs border border-white/10 transition-all cursor-pointer"
                  >
                    Skip for Now
                  </button>
                  <button
                    id="contribute-proceed-btn"
                    type="button"
                    onClick={handleProceedToContributionPayment}
                    disabled={!contributionAmount || contributionAmount <= 0}
                    className="bg-[#FFB347] hover:bg-[#F27D26] disabled:bg-white/10 disabled:text-white/30 text-[#021816] font-extrabold py-3 rounded-xl text-xs uppercase tracking-wide transition-all cursor-pointer"
                  >
                    Contribute ₹{contributionAmount || 0}
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          
          /* ACTIVE DEVOTEE WORKSPACE WITH FLOATING VIRTUAL ID CARD */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fadeIn text-white">
            
            {/* Left Box: Professional Dharmic ID Card + Transactions Ledger (cols 5) */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <h3 className="font-serif text-xl font-bold text-white mb-4 text-center">My Dharmic ID</h3>
              
              {/* PROFESSIONAL DHARMIC ID CARD — corporate-ID-inspired layout on the Dharmic_ID.jpg backdrop */}
              <div 
                id="digital-dharmic-id-card"
                className="relative w-full max-w-md text-white p-5 sm:p-6 rounded-3xl shadow-2xl overflow-hidden border-2 border-[#FFB347]/50 transform hover:-translate-y-2 hover:rotate-1 transition-all duration-300"
              >
                {/* Photo backdrop with a real webp/jpg fallback pair, sitting behind the gradient + content */}
                <OptimizedImage
                  src={dharmicIdBg}
                  webpSrc={dharmicIdBgWebp}
                  alt=""
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover pointer-events-none select-none"
                />
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    backgroundImage: `linear-gradient(135deg, rgba(9,35,32,0.55), rgba(2,24,22,0.6) 55%, rgba(4,47,42,0.5))`,
                  }}
                />
                {/* Mandala Background Watermarks — unchanged, kept visible over the new backdrop */}
                <div className="absolute top-2 right-2 text-9xl text-white/10 font-serif pointer-events-none select-none">
                  ॐ
                </div>
                <div className="absolute -left-10 -bottom-10 text-9xl text-[#FFB347]/10 font-sans pointer-events-none select-none">
                  श्री
                </div>

                {/* Card Header — brand logo centered at top, like a corporate ID crest */}
                <div className="relative flex flex-col items-center border-b border-white/10 pb-2 mb-2.5">
                  <SriDwarLogo variant="colored" iconSize="sm" className="mx-auto justify-center" showTagline={false} />
                  <span className="mt-1.5 text-[9px] font-bold tracking-[0.2em] uppercase text-[#FFB347]/80">
                    Dharmic Identity Card
                  </span>
                </div>

                {/* Shradhalu Name */}
                <div className="relative mb-3 text-left">
                  <span className="text-[9px] text-white/60 block uppercase">Shradhalu Name</span>
                  <span className="font-serif font-black text-base text-[#FFB347] truncate block">{userProfile.name}</span>
                </div>

                {/* Card Main Info layout */}
                <div className="relative grid grid-cols-1 sm:grid-cols-2 gap-x-3 gap-y-2.5 text-xs font-mono mb-2.5 text-left">
                  <div>
                    <span className="text-[9px] text-white/60 block uppercase">Dharmic ID</span>
                    <span className="font-bold block">SDM-23491-IN2</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-white/60 block uppercase">Membership Tier</span>
                    <span className="font-bold text-white block truncate">Lifetime Shradhalu</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-white/60 block uppercase">Gotra / Lineage</span>
                    <span className="font-bold text-white block truncate">{userGotra}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-white/60 block uppercase">Sign / Rashi</span>
                    <span className="font-bold block truncate">{userRashi}</span>
                  </div>
                </div>

                {/* Card footer Bar — with real Sri Dwar QR code for verification */}
                <div className="relative flex items-center gap-2.5 text-[8px] font-mono bg-[#021816]/60 p-2 rounded-xl mt-2.5">
                  <div className="flex-1 flex flex-col gap-1 min-w-0">
                    <div className="flex justify-between items-center">
                      <span>Registered: June 2026</span>
                      <span>Valid Till: June 2027</span>
                    </div>
                    <div className="flex justify-center items-center text-emerald-350 pt-1 border-t border-white/5">
                      <ShieldCheck className="w-3 h-3 text-emerald-400 mr-1" />
                      <span>Secured by Sridwar Technology</span>
                    </div>
                  </div>
                  <OptimizedImage
                    src={sridwarQR}
                    webpSrc={sridwarQRWebp}
                    alt="Sri Dwar verification QR code"
                    loading="lazy"
                    width={48}
                    height={48}
                    className="shrink-0 w-12 h-12 rounded-md object-cover border border-white/10"
                  />
                </div>
              </div>

              {/* MY SPIRITUAL TRANSACTIONS LEDGER — moved directly below the ID card */}
              <div className="w-full max-w-md mt-6 text-left">
                <h3 className="font-serif text-lg font-bold text-white border-b border-white/10 pb-2 mb-4">
                  My Spiritual Transactions Ledger
                </h3>

                {/* Dynamic booked seva list from wizard success */}
                <div className="space-y-4">
                  {bookedItems.length > 0 ? (
                    <div>
                      <span className="text-xs font-bold text-[#5EEAD4] uppercase tracking-wider font-mono block mb-2 text-left">Booked Ceremonies</span>
                      <div className="space-y-3">
                        {bookedItems.map((item, idx) => (
                          <div
                            key={idx}
                            id={`booked-item-ledg-${idx}`}
                            className="bg-[#092320] border border-white/10 p-4 rounded-2xl shadow-sm text-left relative overflow-hidden"
                          >
                            <div className="absolute right-4 top-4 text-2xl">🐚</div>
                            <h4 className="font-serif text-sm font-bold text-white">{item.pujaName}</h4>
                            <span className="text-[10px] text-white/50 font-mono font-medium block">Reference Key: {item.refId} | Date: {item.date}</span>
                            <div className="flex justify-between items-center mt-3 pt-3 border-t border-white/5 text-xs">
                              <span className="font-bold text-[#FFB347]">Paid: ₹{item.price}</span>
                              <span className="bg-[#FFB347]/10 text-[#FFB347] border border-[#FFB347]/20 px-2 py-0.5 rounded-full font-mono text-[9px] font-bold uppercase animate-pulse">
                                Sankalpa Scheduled
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-white/40 py-4 italic text-left">No dynamic pujas scheduled in this current browser session yet. Use the header "Book a Puja" to watch live results.</p>
                  )}
                </div>
              </div>

              {/* SYNCED ACCOUNT ACTIVITY — every puja, seva, bazaar order,
                  contribution and registration on this Dharmic ID, pulled
                  straight from Supabase, so it's the same on every device
                  and shows the real payment status (not just "this
                  browser's session"). Purely additive to the ledger above. */}
              <div className="w-full max-w-md mt-6 text-left" id="synced-activity-ledger">
                <h3 className="font-serif text-lg font-bold text-white border-b border-white/10 pb-2 mb-4">
                  All Account Activity
                </h3>
                {activityRecords.length > 0 ? (
                  <div className="space-y-3">
                    {activityRecords.map((rec) => {
                      const badge = paymentStatusBadge(rec.paymentStatus);
                      return (
                        <div
                          key={rec.id}
                          id={`synced-activity-${rec.id}`}
                          className="bg-[#092320] border border-white/10 p-4 rounded-2xl shadow-sm text-left relative overflow-hidden"
                        >
                          <span className="text-[9px] text-[#5EEAD4] font-mono uppercase tracking-wider block mb-1">
                            {ACTIVITY_TYPE_LABELS[rec.activityType] || "Offering"}
                          </span>
                          <h4 className="font-serif text-sm font-bold text-white pr-4">{rec.itemName}</h4>
                          <span className="text-[10px] text-white/50 font-mono font-medium block">
                            Ref: {rec.refId} | {new Date(rec.createdAt).toLocaleDateString()}
                          </span>
                          <div className="flex justify-between items-center mt-3 pt-3 border-t border-white/5 text-xs">
                            <span className="font-bold text-[#FFB347]">₹{rec.amount}{rec.paymentMethod ? ` · ${rec.paymentMethod}` : ""}</span>
                            <span className={`px-2 py-0.5 rounded-full font-mono text-[9px] font-bold uppercase border ${badge.cls}`}>
                              {badge.label}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-xs text-white/40 py-4 italic text-left">
                    No synced activity yet — bookings, sevas, orders and contributions made on this Dharmic ID will appear here.
                  </p>
                )}
              </div>

              {/* MY REQUESTS & SUBMISSIONS — non-monetary account activity:
                  Contact Us messages, testimonials, Darshan Certificate
                  requests, and registration submissions tied to this login. */}
              {formSubmissions.length > 0 && (
                <div className="w-full max-w-md mt-6 text-left" id="synced-form-submissions">
                  <h3 className="font-serif text-lg font-bold text-white border-b border-white/10 pb-2 mb-4">
                    My Requests & Submissions
                  </h3>
                  <div className="space-y-2.5">
                    {formSubmissions.map((sub) => (
                      <div
                        key={sub.id}
                        className="bg-[#092320] border border-white/10 px-4 py-3 rounded-2xl text-left flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <span className="text-[10px] text-[#5EEAD4] font-mono uppercase tracking-wider block">
                            {FORM_TYPE_LABELS[sub.formType] || sub.formType}
                          </span>
                          <span className="text-xs text-white/70 block truncate">
                            {new Date(sub.createdAt).toLocaleDateString()}{sub.refId ? ` · Ref: ${sub.refId}` : ""}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Log out option */}
              <button
                id="dashboard-logout-btn"
                onClick={onLogout}
                className="mt-6 flex items-center space-x-1.5 px-4 py-2 bg-white/5 border border-white/10 text-white/90 hover:bg-white/15 hover:text-white rounded-full text-xs font-bold transition-all shadow-sm cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5 text-[#FFB347]" />
                <span>Log Out of workspace</span>
              </button>
            </div>

            {/* Right Box: My Sacred Profile management, moved to the right side (cols 7) */}
            <div className="lg:col-span-7 space-y-6">

              {/* SUPPORT OUR MISSION PANEL — restored so an already-logged-in
                  devotee can start a new offering from their own Profile
                  page, instead of only during first-time Dharmic ID
                  generation. Also shows a 5-point summary of how offerings
                  are used and impact is reported back to the devotee. */}
              <div
                id="profile-contribute-panel"
                className="w-full bg-[#092320] border border-white/10 rounded-3xl p-5 text-left text-white space-y-3.5"
              >
                <div className="flex items-center space-x-2 border-b border-white/5 pb-2">
                  <span className="text-lg">🙏</span>
                  <h4 className="font-serif text-sm font-bold text-white uppercase tracking-wider">
                    Support Our Mission
                  </h4>
                </div>

                {postLoginContributionSuccess && (
                  <div className="bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 p-2.5 rounded-xl text-[10px] text-center font-bold">
                    ✓ Your support has been recorded! It now appears under "All Account Activity" — our team will confirm it shortly.
                  </div>
                )}

                {!showPostLoginContribute ? (
                  <>
                    <p className="text-[10px] text-white/70 leading-relaxed font-sans">
                      One Contribution. Countless Blessings. Be part of Devotee Well-being, Temple Redevelopment, and Sacred Sevas Through Sri Dwar. Together, let's build trust, serve devotees, and strengthen our sacred heritage. Your valuable contribution empowers our culture, community service, and our mission to make every act of devotion meaningful and transparent.
                    </p>
                    <button
                      id="profile-contribute-open-btn"
                      type="button"
                      onClick={() => { setShowPostLoginContribute(true); setPostLoginContributionSuccess(false); }}
                      className="w-full bg-[#FFB347] hover:bg-[#F27D26] text-[#021816] font-extrabold py-2.5 rounded-xl text-xs uppercase tracking-wide transition-all cursor-pointer"
                    >
                      Support Now
                    </button>
                  </>
                ) : (
                  <div className="space-y-3.5 animate-fadeIn">
                    <div>
                      <label className="block text-[10px] font-bold text-white/80 mb-1">Choose a temple from our network</label>
                      <select
                        id="profile-contribute-temple-select"
                        value={selectedTempleId}
                        onChange={(e) => {
                          setSelectedTempleId(e.target.value);
                          if (e.target.value) {
                            setCustomMandapName("");
                            setCustomMandapAddress("");
                          }
                        }}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#021816] text-[#5EEAD4] font-medium focus:outline-none focus:border-[#5EEAD4]"
                      >
                        <option value="">-- Select a temple --</option>
                        {TEMPLES_LIST.map((temple) => (
                          <option key={temple.id} value={temple.id}>{temple.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="sanskrit-divider text-[10px]">or</div>

                    <div className="space-y-2">
                      <input
                        id="profile-contribute-custom-mandap-name"
                        type="text"
                        placeholder="Mandap / Temple name"
                        value={customMandapName}
                        onChange={(e) => {
                          setCustomMandapName(e.target.value);
                          if (e.target.value) setSelectedTempleId("");
                        }}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#021816] text-white placeholder-white/30 focus:outline-none focus:border-[#5EEAD4]"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-white/80 mb-1">Support Amount (₹)</label>
                      <div className="grid grid-cols-3 gap-2 mb-2">
                        {[51, 101, 251].map((amt) => (
                          <button
                            key={amt}
                            id={`profile-contribute-amount-tier-${amt}`}
                            type="button"
                            onClick={() => setContributionAmount(amt)}
                            className={`text-xs py-2 rounded-xl border font-bold transition-all ${
                              contributionAmount === amt
                                ? "bg-white/10 border-[#5EEAD4] text-[#5EEAD4] shadow-sm"
                                : "bg-black/20 border-white/10 text-white/70 hover:bg-black/30"
                            }`}
                          >
                            ₹{amt}
                          </button>
                        ))}
                      </div>
                      <input
                        id="profile-contribute-custom-amount"
                        type="number"
                        min={1}
                        placeholder="Or enter a custom amount"
                        value={contributionAmount || ""}
                        onChange={(e) => setContributionAmount(Math.max(0, Number(e.target.value)))}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#021816] text-white placeholder-white/30 focus:outline-none focus:border-[#5EEAD4]"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-1">
                      <button
                        id="profile-contribute-cancel-btn"
                        type="button"
                        onClick={() => setShowPostLoginContribute(false)}
                        className="bg-white/5 hover:bg-white/10 text-white font-bold py-2.5 rounded-xl text-xs border border-white/10 transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        id="profile-contribute-proceed-btn"
                        type="button"
                        onClick={handleProceedToContributionPayment}
                        disabled={!contributionAmount || contributionAmount <= 0}
                        className="bg-[#FFB347] hover:bg-[#F27D26] disabled:bg-white/10 disabled:text-white/30 text-[#021816] font-extrabold py-2.5 rounded-xl text-xs uppercase tracking-wide transition-all cursor-pointer"
                      >
                        Support with ₹{contributionAmount || 0}
                      </button>
                    </div>
                  </div>
                )}

                {/* How your support is used — 5-point impact summary */}
                <div className="border-t border-white/5 pt-3 space-y-2.5">
                  <p className="text-[10px] text-white/60 italic leading-relaxed">
                    Don't just offer your devotion — see it come alive.
                  </p>
                  <div className="flex items-start gap-2 text-[10px] text-white/50 font-mono leading-relaxed">
                    <Landmark className="w-3 h-3 shrink-0 mt-0.5 text-[#5EEAD4]" />
                    <span>Every booking, seva, order, and contribution you make directly supports your chosen temple or local puja mandal.</span>
                  </div>
                  <div className="flex items-start gap-2 text-[10px] text-white/50 font-mono leading-relaxed">
                    <Utensils className="w-3 h-3 shrink-0 mt-0.5 text-[#5EEAD4]" />
                    <span>Your generosity funds Annadanam — free sacred meals served to devotees.</span>
                  </div>
                  <div className="flex items-start gap-2 text-[10px] text-white/50 font-mono leading-relaxed">
                    <Armchair className="w-3 h-3 shrink-0 mt-0.5 text-[#5EEAD4]" />
                    <span>It also funds seating facilities, a shed, waiting halls, and comfort for devotees visiting the pilgrimage sites.</span>
                  </div>
                  <div className="flex items-start gap-2 text-[10px] text-white/50 font-mono leading-relaxed">
                    <Hammer className="w-3 h-3 shrink-0 mt-0.5 text-[#5EEAD4]" />
                    <span>Your offering supports maintenance and other sacred initiatives.</span>
                  </div>
                  <div className="flex items-start gap-2 text-[10px] text-white/50 font-mono leading-relaxed">
                    <FileCheck className="w-3 h-3 shrink-0 mt-0.5 text-[#FFB347]" />
                    <span>After the seva is completed, we share photo or video proof of the impact when available and issue your personalized Digital Seva Certificate within 7 working days.</span>
                  </div>
                  <p className="text-[10px] text-[#FFB347] italic leading-relaxed pt-1">
                    Every offering becomes a blessing. Every blessing creates a difference.
                  </p>
                </div>
              </div>

              {/* MY SACRED PROFILE MANAGEMENT CARD */}
              <div 
                id="my-sacred-profile-card"
                className="w-full bg-[#092320] border border-white/10 rounded-3xl p-5 text-left text-white space-y-4"
              >
                <div className="flex items-center space-x-2 border-b border-white/5 pb-2">
                  <span className="text-lg">🕉️</span>
                  <h4 className="font-serif text-sm font-bold text-white uppercase tracking-wider">
                    My Sacred Profile
                  </h4>
                </div>

                <form onSubmit={handleSaveProfile} className="space-y-3.5">
                  {/* Phone number */}
                  <div>
                    <label className="block text-[10px] font-bold text-white/80 uppercase tracking-wide mb-1 text-left">
                      Mobile / WhatsApp Number
                    </label>
                    <input
                      id="profile-phone"
                      type="text"
                      placeholder="e.g. +91 98765 43210"
                      value={userPhone}
                      onChange={(e) => setUserPhone(e.target.value)}
                      className="w-full text-xs px-3.5 py-2 rounded-xl border border-white/10 bg-[#021816] text-[#5EEAD4] focus:outline-none focus:border-[#5EEAD4] text-left font-semibold"
                    />
                  </div>

                  {/* Gotra lineage */}
                  <div>
                    <label className="block text-[10px] font-bold text-white/80 uppercase tracking-wide mb-1 text-left">
                      Gotra Ancestry *
                    </label>
                    <input
                      id="profile-gotra"
                      type="text"
                      required
                      placeholder="e.g. Vatsasa Gotra"
                      value={userGotra}
                      onChange={(e) => setUserGotra(e.target.value)}
                      className="w-full text-xs px-3.5 py-2 rounded-xl border border-white/10 bg-[#021816] text-white focus:outline-none focus:border-[#5EEAD4] text-left font-semibold"
                    />
                  </div>

                  {/* Moon Sign Rashi */}
                  <div>
                    <label className="block text-[10px] font-bold text-white/80 uppercase tracking-wide mb-1 text-left">
                      Vedic Astro Rashi (Moon Sign)
                    </label>
                    <select
                      id="profile-rashi"
                      value={userRashi}
                      onChange={(e) => setUserRashi(e.target.value)}
                      className="w-full text-xs px-3.5 py-2 rounded-xl border border-white/10 bg-[#021816] text-[#5EEAD4] focus:outline-none focus:border-[#5EEAD4] font-semibold"
                    >
                      <option value="Mesh (Aries)">Mesh (Aries)</option>
                      <option value="Vrishabh (Taurus)">Vrishabh (Taurus)</option>
                      <option value="Mithun (Gemini)">Mithun (Gemini)</option>
                      <option value="Kark (Cancer)">Kark (Cancer)</option>
                      <option value="Simha (Leo)">Simha (Leo)</option>
                      <option value="Kanya (Virgo)">Kanya (Virgo)</option>
                      <option value="Tula (Libra)">Tula (Libra)</option>
                      <option value="Vrishchik (Scorpio)">Vrishchik (Scorpio)</option>
                      <option value="Dhanu (Sagittarius)">Dhanu (Sagittarius)</option>
                      <option value="Makar (Capricorn)">Makar (Capricorn)</option>
                      <option value="Kumbh (Aquarius)">Kumbh (Aquarius)</option>
                      <option value="Meen (Pisces)">Meen (Pisces)</option>
                    </select>
                  </div>

                  {/* Family Members Sub-section */}
                  <div className="border-t border-white/5 pt-3.5 space-y-2">
                    <span className="block text-[10px] font-bold text-white/85 uppercase tracking-wide text-left">
                      Family Members (Chanting Sankalpa)
                    </span>

                    {familyMembers.length > 0 ? (
                      <div className="space-y-1.5 max-h-28 overflow-y-auto pr-1">
                        {familyMembers.map((member, index) => (
                          <div 
                            key={index} 
                            className="flex items-center justify-between text-[11px] bg-[#021816] px-3 py-1.5 rounded-lg border border-white/5"
                          >
                            <span className="text-white font-medium truncate max-w-[120px] text-left">{member.name}</span>
                            <span className="text-[#FFB347] font-sans text-[10px] px-1.5 py-0.5 bg-white/5 rounded border border-white/5">{member.relation}</span>
                            <button
                              type="button"
                              onClick={() => handleRemoveFamilyMember(index)}
                              className="text-red-400 hover:text-red-500 hover:scale-115 transition-all p-0.5 cursor-pointer bg-transparent border-none"
                              title="Remove family member"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-[10px] text-white/40 italic text-left text-left">
                        No family members registered yet.
                      </p>
                    )}

                    {/* Add Member inputs */}
                    <div className="grid grid-cols-12 gap-1.5 pt-1">
                      <div className="col-span-6">
                        <input
                          id="profile-family-new-name"
                          type="text"
                          placeholder="Member Name"
                          value={newMemberName}
                          onChange={(e) => setNewMemberName(e.target.value)}
                          className="w-full text-[10px] px-2 py-1.5 rounded-lg border border-white/10 bg-[#021816] text-white focus:outline-none"
                        />
                      </div>
                      <div className="col-span-4">
                        <select
                          id="profile-family-new-relation"
                          value={newMemberRelation}
                          onChange={(e) => setNewMemberRelation(e.target.value)}
                          className="w-full text-[10px] px-1.5 py-1.5 rounded-lg border border-white/10 bg-[#021816] text-[#5EEAD4] focus:outline-none cursor-pointer"
                        >
                          <option value="Spouse">Spouse</option>
                          <option value="Son">Son</option>
                          <option value="Daughter">Daughter</option>
                          <option value="Father">Father</option>
                          <option value="Mother">Mother</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                      <div className="col-span-2">
                        <button
                          type="button"
                          onClick={(e) => handleAddFamilyMember(e)}
                          className="w-full h-full bg-[#5EEAD4] hover:bg-[#14B8A6] text-[#021816] font-extrabold flex items-center justify-center rounded-lg transition-colors cursor-pointer border-none"
                          title="Add Member"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Submission and Saving status bar */}
                  <div className="pt-2">
                    <button
                      id="save-sacred-profile-btn"
                      type="submit"
                      className="w-full bg-[#0F766E] hover:bg-[#14B8A6] text-white font-bold text-[10px] uppercase tracking-widest py-2.5 px-4 rounded-xl shadow transition-transform active:scale-95 flex items-center justify-center space-x-1.5 cursor-pointer border-none"
                    >
                      <Save className="w-3.5 h-3.5 text-[#FFB347]" />
                      <span>Save Sacred Profile</span>
                    </button>

                    {saveProfileSuccess && (
                      <div className="mt-2 bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 p-2 rounded-xl text-[10px] text-center font-bold animate-pulse">
                        ✓ Sacred Profile & Gotra Lineage Saved!
                      </div>
                    )}
                  </div>
                </form>
              </div>
            </div>

          </div>

        )}

      </div>

      {/* ── Step 3: Puja Sankalpa Portal ─────────────────────────────────── */}
      {showSankalpaForm && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-[200] overflow-y-auto p-4 py-6">
          <div className="bg-[#092320] rounded-3xl w-full max-w-sm border border-white/10 shadow-2xl mx-auto my-4 text-white">

            {/* Header with SriDwarLogo */}
            <div className="bg-[#021816] px-5 py-4 border-b border-white/10 rounded-t-3xl">
              <div className="flex justify-center mb-3">
                <SriDwarLogo variant="colored" iconSize="sm" showTagline={false} />
              </div>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-serif text-sm font-bold text-white">Puja Sankalpa Portal</h3>
                  <p className="text-[10px] font-mono text-[#FFB347] uppercase tracking-wider mt-0.5">
                    Temple Redevelopment Contribution
                  </p>
                </div>
                <button
                  onClick={() => setShowSankalpaForm(false)}
                  className="text-white/60 hover:text-white p-1.5 bg-white/5 rounded-full border border-white/10 shrink-0 ml-2"
                >
                  ✕
                </button>
              </div>
            </div>

            <form onSubmit={handleSankalpaSubmit} className="p-5 space-y-4">

              {/* Contribution summary */}
              <div className="bg-[#021816] rounded-2xl p-3 border border-white/10 flex items-center justify-between">
                <div className="text-xs text-white/60 font-mono truncate max-w-[180px]">
                  {selectedTempleId
                    ? TEMPLES_LIST.find(t => t.id === selectedTempleId)?.name
                    : customMandapName || "Temple Contribution"}
                </div>
                <span className="text-sm font-extrabold text-[#FFB347] font-serif shrink-0 ml-2">
                  ₹{contributionAmount}
                </span>
              </div>

              <p className="text-[11px] text-white/60 leading-relaxed">
                🙏 Please confirm your details so our pandits can register this contribution Sankalpa in your name and Gotra.
              </p>

              {/* Devotee name — pre-filled from login, read-only */}
              <div>
                <label className="block text-xs font-bold text-white/80 mb-1">Devotee Name</label>
                <input
                  type="text"
                  readOnly
                  value={pendingLogin?.name || ""}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-black/20 border border-white/5 text-white/60 cursor-not-allowed"
                />
              </div>

              {/* WhatsApp */}
              <div>
                <label className="block text-xs font-bold text-white/80 mb-1">WhatsApp Number *</label>
                <input
                  type="tel"
                  required
                  value={sankalpaPhone}
                  onChange={e => setSankalpaPhone(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/10 focus:outline-none focus:border-[#5EEAD4] text-white placeholder-white/35"
                />
              </div>

              {/* Gotra */}
              <div>
                <label className="block text-xs font-bold text-white/80 mb-1">
                  Gotra <span className="text-white/40 font-normal">(Optional — auto-filled from your profile)</span>
                </label>
                <input
                  type="text"
                  value={sankalpaGotra || userGotra}
                  onChange={e => setSankalpaGotra(e.target.value)}
                  placeholder="e.g. Kashyap"
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/10 focus:outline-none focus:border-[#5EEAD4] text-white placeholder-white/35"
                />
              </div>

              {/* Sankalpa Intention */}
              <div>
                <label className="block text-xs font-bold text-white/80 mb-1">
                  Sankalpa Intention <span className="text-white/40 font-normal">(Optional)</span>
                </label>
                <textarea
                  rows={2}
                  value={sankalpaIntent}
                  onChange={e => setSankalpaIntent(e.target.value)}
                  placeholder="e.g. For the health and prosperity of my family..."
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/10 focus:outline-none focus:border-[#5EEAD4] text-white placeholder-white/35 resize-none"
                />
                <p className="text-[10px] text-white/30 mt-1 font-mono">Recited by the pandit during Sankalpa</p>
              </div>

              <div className="flex items-start gap-2 bg-emerald-950/30 border border-emerald-500/20 px-3 py-2.5 rounded-xl text-[10px] text-emerald-300 font-mono">
                <ShieldCheck className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                <span>A specific puja will be performed in your name at your ista devta temple, and the certificate for that puja will be sent on WhatsApp & Email within 3 working days. 🙏</span>
              </div>

              <button
                type="submit"
                className="w-full bg-[#FFB347] hover:bg-[#F27D26] text-[#021816] font-extrabold py-3 rounded-xl text-xs tracking-widest uppercase transition-all shadow flex items-center justify-center gap-2"
              >
                Proceed to Sacred Offering →
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ── Step 5: Complete Your Sacred Offering (UPI Payment) ───────────── */}
      <UPIPaymentModal
        isOpen={isContributionPaymentOpen}
        onClose={() => setIsContributionPaymentOpen(false)}
        onPaymentConfirmed={finalizeContribution}
        amount={contributionAmount}
        bookingName={`Temple Contribution — ${
          selectedTempleId
            ? TEMPLES_LIST.find(t => t.id === selectedTempleId)?.name || "Temple"
            : customMandapName || "Temple Redevelopment"
        }`}
        devoteeName={pendingLogin?.name || "Devotee"}
        refId={contributionRefId}
      />
    </section>
  );
}
