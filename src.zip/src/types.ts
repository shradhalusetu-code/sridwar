/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface TempleCoordinates {
  lat: number;
  lng: number;
}

export interface AartiTimings {
  morning: string;
  afternoon: string;
  evening: string;
  note?: string; // used when exact published timings are not publicly confirmed / vary seasonally
}

export interface Temple {
  id: string;
  name: string;
  city: string;
  state: string;
  deity: string;
  story: string;
  deityInfo: string;
  timings: string;
  rituals: string[]; // "Authorized Rituals" — 10-15 rituals actually performed at the temple
  imageUrl: string;
  symbol: string; // Sanskrit/sacred characters or shorthand
  coordinates: TempleCoordinates; // verified approximate GPS location of the temple
  history: string; // "Holy Pilgrimage Narrative & History" — 100+ word researched account
  aartiTimings: AartiTimings; // morning / afternoon / evening aarti schedule
  sampleOfferings: string[]; // "Sample Rituals & Offerings" — 10-15 offerings devotees can sponsor
  priestInfo: string; // information about the priests who perform pujas at this temple
}

export interface Seva {
  id: string;
  name: string;
  templeAssociation: string;
  significance: string;
  blessingExplanation: string;
  impactStat: string;
  donationTiers: { amount: number; label: string; description: string }[];
  imageUrl?: string;
}

export interface Puja {
  id: string;
  name: string;
  category: "health" | "wealth" | "protection" | "career" | "marriage" | "education" | "festivals" | "graha_shanti" | "ancestor";
  templeName: string;
  deityName: string;
  benefits: string;
  priestDetails: string;
  videoAvailable: boolean;
  prasadIncluded: boolean;
  price: number;
  imageUrl: string;
  duration?: string;
  materialsIncluded?: string[];
}

export interface PriestProfile {
  id: string;                      // dedicated profile id, used for detail view lookup
  priestDetails: string;           // exact string match to Puja.priestDetails — keeps existing flow intact
  name: string;
  yearsExperience: number;         // years of experience performing pujas/rituals
  yearsHelpingDevotees: number;    // years actively helping devotees with puja & religious activities
  currentCity: string;
  currentState: string;
  templesAssociated: string[];
  deitiesServed: string[];
  pujaExpertise: string[];         // puja specializations
  adviceAreas: string[];           // advice/specialization areas devotees can consult on
  languagesSpoken: string[];
  bio: string;
  isVerified: boolean;
  // rating and devoteesServedApprox were removed as required fields: they
  // used to hold a per-priest star rating (4.5–4.9) and a "devotees served"
  // headcount that were invented placeholder numbers, not real review data,
  // yet were displayed in PriestSection.tsx next to copy telling devotees
  // to "read ratings and feedback from other devotees" — i.e. fabricated
  // numbers presented as genuine reviews. Left optional (rather than
  // deleted outright) in case a real review/rating system is wired up
  // later; until then, no priest profile sets them and the UI no longer
  // renders them.
  rating?: number;                 // out of 5 — only set this from real, aggregated devotee reviews
  devoteesServedApprox?: number;   // only set this from a real, countable figure
  associatedPujaIds: string[];     // links back to ON_LINE_PUJAS entries
}

export interface Product {
  id: string;
  name: string;
  category: "prasad" | "rudraksha" | "incense" | "diyas" | "jewellery" | "books" | "kits" | "hampers";
  templeStory: string;
  significance: string;
  authenticity: string;
  blessings: string;
  price: number;
  imageUrl: string;
  rating: number;
  deliveryTimeline: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface DevoteeProfile {
  name: string;
  gotra: string;
  primaryDeity: string;
  visitedTemples: string[];
  dharmicID: string;
  joinedAt: string;
  donationHistory: { id: string; date: string; purpose: string; amount: number; type: string }[];
}

export interface Mantra {
  text: string;
  translation: string;
  significance: string;
  audioSimText: string;
}

export interface DailyHoroscope {
  sign: string;
  prediction: string;
  luckyNumber: number;
  luckyColor: string;
  remedy: string;
}
